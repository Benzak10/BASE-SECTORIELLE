"""Cours de marché (contrats à terme continus) via Yahoo Finance — cours de clôture quotidiens."""
from __future__ import annotations

import pandas as pd


def collect(source_id: str, src: dict, series: list[dict]):
    import yfinance as yf

    annees = src.get("historique_annees", 10)
    out = []
    for s in series:
        ticker = s["params"]["ticker"]
        h = yf.Ticker(ticker).history(period=f"{annees}y", interval="1d", auto_adjust=False)
        if h is None or h.empty or "Close" not in h:
            raise RuntimeError(f"Aucune donnée Yahoo Finance pour {ticker}")
        close = h["Close"].dropna()
        idx = close.index.tz_localize(None) if close.index.tz is not None else close.index
        out.append(pd.DataFrame({"id": s["id"], "date": idx.normalize(),
                                 "valeur": close.values.astype(float)}))
    return pd.concat(out), "Yahoo Finance"
